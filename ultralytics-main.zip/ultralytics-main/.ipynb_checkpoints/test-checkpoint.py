from ultralytics.models import YOLO
import os
import torch

try:
    # 设置CUDA内存分配策略
    os.environ['PYTORCH_CUDA_ALLOC_CONF'] = 'max_split_size_mb:128'
    
    # 清理CUDA缓存
    torch.cuda.empty_cache()
    
    # 加载你的模型配置文件
    #model = YOLO("yolov8s.pt")
    #model = YOLO("ultralytics/cfg/models/v8/yolov8s.yaml")
    model = YOLO("ultralytics/cfg/models/v8/yolov8_smallob.yaml")
    #model = YOLO("ultralytics/cfg/models/v8/yolov8s-Backbone-ATT.yaml")
    # 开始训练之前再次清理CUDA缓存
    torch.cuda.empty_cache()

    # 训练模型
    model.train(data="/root/autodl-tmp/ultralytics-main/dataset/VisDrone2019/data.yaml", 
                workers=4, 
                batch=8, 
                epochs=300, 
                imgsz=640,
                project="runs",
                name="yolov8s"
               )

except Exception as e:
    print(f"An error occurred: {e}")

finally:
    # 无论程序是否正常完成，都会执行关机命令
    os.system('shutdown -h now')   
    print("System is shutting down.")
